<?php

namespace App\Containers\AppSection\Settings\Models;

use App\Ship\Parents\Models\Model as ParentModel;

class Settings extends ParentModel
{
}
