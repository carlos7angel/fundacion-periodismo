### Localization Container

