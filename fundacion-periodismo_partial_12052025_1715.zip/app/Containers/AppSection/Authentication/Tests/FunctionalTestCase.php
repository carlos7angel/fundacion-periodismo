<?php

namespace App\Containers\AppSection\Authentication\Tests;

class FunctionalTestCase extends ContainerTestCase
{
}
