<?php

namespace App\Containers\AppSection\Authentication\Tests;

class UnitTestCase extends ContainerTestCase
{
}
